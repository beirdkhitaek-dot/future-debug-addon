# Future Debug Meteor Addon

A clean Meteor Client addon conversion of the two `FutureDebug` modules found in the supplied WaterClient JAR.

## Included modules

- `future-debug`
- `future-debug-render`

No other WaterClient modules, embedded libraries, mixins, WaterClient entrypoints, or leak metadata are included.

## Target

- Minecraft 1.21.11
- Java 21
- Fabric Loader 0.18.4+
- Meteor Client 1.21.11-SNAPSHOT

## Build

Run (needs Gradle 9.2+ and JDK 21; or just push to GitHub and use the Actions tab):

```bash
gradle build
```

Then put:

```text
build/libs/future-debug-addon-1.0.0.jar
```

into the Minecraft `mods` directory alongside Meteor Client.

## Notes

The original JAR uses WaterClient-specific classes and rendering utilities, so its `.class` files cannot simply be dropped into a Meteor addon. This project reimplements the module behavior against Meteor's addon API instead.

The scanner runs asynchronously and only examines already-loaded chunks.
